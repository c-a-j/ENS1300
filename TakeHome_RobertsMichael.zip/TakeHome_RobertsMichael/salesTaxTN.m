function cost = salesTaxTN(food, other)

end

function y = foodTax(x)

end

function y = otherTax(x)

end

function y = localTax(x)

end