function student = calcGrade2(student)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Purpose: calcGrade2() calculates one student's grade
%%% Inputs:
    % student is a structure with the fields exams, labs, quizzes, and
        % projects
%%% Output: 
    % student is a structure with the fields exams, labs, quizzes,
        % projects, and avgGrade
%%% Usage: student = calcGrade2(student); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    student.avgGrade = mean(student.exams)*0.4 + mean(student.labs)*0.4 ...
        + mean(student.quizzes)*0.1 + mean(student.projects)*0.1;
end