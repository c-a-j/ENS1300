function sphereCoords = cart2sphere_uno
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Purpose: sphereCoords_uno() converts cartesian coordinates to spherical
%%% Inputs: none
%%% Output: shpereCoords is an array of spherical coordinates
%%% Usage: sphereCoords = cart2sphere(); 
%%% Notes: user must supply input coordinates via the command window
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    cartCoords = getInput();
    sphereCoords = convertCoords(cartCoords);
    printOutput(sphereCoords);
end

function cartCoords = getInput()
% get single input coordinate fom user via command window
    msg = 'Enter the cartesian coordinates of a point in vector format [x y z]: ';
    cartCoords = input(msg);
end

function sphereCoords = convertCoords(cartCoords)
% convert the coordinates
    x = cartCoords(:,1);
    y = cartCoords(:,2);
    z = cartCoords(:,3);
    r = (x.^2 + y.^2 + z.^2).^(1/2);
    theta = acosd(z./r);
    phi = atand(y./x);
    sphereCoords = [r,theta,phi];
end

function printOutput(sphereCoords)
% print results to command window
    r = sphereCoords(:,1);
    theta = sphereCoords(:,2);
    phi = sphereCoords(:,3);
    fprintf('\nThe radius is %0.2f\n', r)
    fprintf('The inclanation angle is %0.2f\n', theta)
    fprintf('The azimuth angle is %0.2f\n\n', phi)
end