function multTable(n)
    if nargin ~=1
        n = 20;
    end
    fID = fopen('multTable.txt','w');
    for i = 1:n
        for j = 1:n
            fprintf(fID,'%d\t',i*j);
        end
        fprintf(fID,'\n');
    end
    fclose(fID);
end