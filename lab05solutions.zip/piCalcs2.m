function piCalcs2(n)
    if nargin ~= 1
        n = 100;
    end
    Wells(n);
    GregoryLeibniz(n);
    Bellard(n);
    BorweinBailey(n)
    Euler(n)
end

function Wells(n)
    vals = zeros(n,1);
    k = 0;
    mypi = 2;
    for i = 1:n
        k = k+1;
        num = (2*k)^2;
        den = (2*k-1)*(2*k+1);
        mypi = mypi*(num/den);
        vals(i) = mypi;
    end
    plotFunc(n,vals,'Wells'' Pi Product')
end

function GregoryLeibniz(n)
    vals = zeros(n,1);
    k = 0;
    mypi = 0;
    for i = 1:n
        k = k + 1;
        num = (-1)^(k-1);
        den = 2*k-1;
        mypi = mypi + num/den;
        vals(i) = 4*mypi;
    end
    plotFunc(n,vals,'Gregory Leibniz Pi Series')
end

function Bellard(n)
    vals = zeros(n,1);
    k = 0;
    mysum = 0;
    for i = 1:n
        num = (-1)^(k);
        den = 2^(10*k);
        phi = num/den;
        terms = [-(2^5)/(4*k+1)
                -(1)/(4*k+3)
                (2^8)/(10*k+1)
                -(2^6)/(10*k+3)
                -(2^2)/(10*k+5)
                -(2^2)/(10*k+7)
                (1)/(10*k+9)];
        mysum = mysum + phi*sum(terms);
        vals(i) = (2^-6)*mysum;
        k = k + 1;
    end
    plotFunc(n,vals,'Belllard Pi Series')
end

function BorweinBailey(n)
    vals = zeros(n,1);
    k = 0;
    mypi = 0;
    for i = 1:n
        phi = 16^-k;
        terms = [(4)/(8*k+1)
                -(2)/(8*k+4)
                -(1)/(8*k+5)
                -(1)/(8*k+6)];
        mypi = mypi + phi*sum(terms);
        vals(i) = mypi;
        k = k + 1;
    end
    plotFunc(n,vals,'Borwein Bailey Pi Series')
end

function Euler(n)
    vals = zeros(n,1);
    k = 1;
    s = 0;
    for i = 1:n
        s = s + 6/k^2;
        vals(i) = sqrt(s);
        k = k + 1;
    end
    plotFunc(n,vals,'Euler Pi Series')
end

function plotFunc(n,vals,titleStr)
    figure
    plot(1:n,vals,'*-',[1,n],[pi,pi],'k-'); hold on
    axis([1,n,min(vals)-0.1,max(vals)+0.1])
    title(titleStr)
    xlabel('Iteration Number')
    ylabel('Iteration Value')
end
