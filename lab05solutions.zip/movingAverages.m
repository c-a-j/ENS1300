function movingAverages(dates, prices)
    n = length(prices)-29;

    % preallocate memory
    fiveDay = zeros(n,1);
    tenDay = zeros(n,1);
    thirtyDay = zeros(n,1);
    % loop to calculate rolling averages for each day
    for i = 1:n
        fiveDay(i) = mean(prices(i:i+4)); 
        tenDay(i) = mean(prices(i:i+9));
        thirtyDay(i) = mean(prices(i:i+29));
    end

    % plot daily price and averages
    prices = prices(1:n);
    fig = figure;
    plot(1:n, flip(prices), 'k-'); hold on
    plot(1:n, flip(fiveDay), 'r-')
    plot(1:n, flip(tenDay), 'g-')
    plot(1:n, flip(thirtyDay), 'b-')

    % annotations
    title('Daily BTC Price Data','FontSize',16)
    legend('Daily Price', '5-Day Average', '10-Day Average', '30-Day Average','FontSize',12)
    ylabel('BTC Price ($)','FontSize',12)
    % adjust x limits for equal white space on sides
    ax = gca;
    ax.XLim = [-10, n+10];
    % set xtick labels to dates
    xt = ax.XTick;
    xtickangle(30); % rotate labels a bit so they don't run into each other
    myxt = dates(xt+1); % vector indexing!!! this gets the correct dates
    ax.XTickLabel = flip(myxt); % dates must be flipped because price was flipped
    
    saveas(fig,'BTC','png')
end