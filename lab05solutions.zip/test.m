%% multTable
multTable(10)

%% piCalcs1
piCalcs1(1e-6)

%% piCalcs2
piCalcs2(50)

%% movingAverages
fn = fullfile('data','BTC.mat');
load(fn)
days = floor(365/2) + 29; % last 6 months
prices = prices(1:days);
dates = dates(1:days);

movingAverages(dates, prices)

%% calcAllGrades  -  good data
fn = fullfile('data','grades.mat');
load(fn)
students = calcAllGrades(students);



%% calcAllGrades  -  bad data
fn = fullfile('data','badGrades.mat');
load(fn)
students = calcAllGrades(students);