function students = calcAllGrades(students)
    if nargin ~= 1
        load('data/badGrades.mat','students')
    end
    
    % get structure field names (student names) for looping
    fields = string(fieldnames(students));

    % loop through all students
    for i = 1:length(fields)
        student = fields(i);
        % check that student contains all grades
        % if so, calculate grade and drop grade
        % if not, display warning and continue to next student
        if studentCheck(students.(student)) 
            students.(student) = calcGrade(students.(student));
            students.(student) = calcDropGrade(students.(student));
        else
            warning('%s is not formatted correctly',student)
        end
    end
end

function student = calcGrade(student)
    exams = student.exams;
    labs = student.labs;
    quizzes = student.quizzes;
    projects = student.projects;
    
    grade = mean(exams)*0.4 + mean(labs)*0.4 ...
        + mean(quizzes)*0.1 + mean(projects)*0.1;
    
    student.letterGrade = determineLetter(grade);
    student.avgGrade = grade;
end

function student = calcDropGrade(student)
    exams = student.exams;
    labs = sort(student.labs);
    labs = labs(2:end);
    quizzes = sort(student.quizzes);
    quizzes = quizzes(3:end);
    projects = student.projects;
    
    grade = mean(exams)*0.4 + mean(labs)*0.4 ...
        + mean(quizzes)*0.1 + mean(projects)*0.1;
        
    student.dropLetterGrade = determineLetter(grade);
    student.dropAvgGrade = grade;
end

function letter = determineLetter(grade)
    % input is a numerical grade
    % output is a letter grade
    % this function is used for both calcGrade and calcDropGrade
    if grade >= 90
        letter = "A";
    elseif grade >= 85 && grade < 90
        letter = "B+";
    elseif grade >= 80 && grade < 85
        letter = "B";
    elseif grade >= 75 && grade < 80
        letter = "C+";
    elseif grade >= 70 && grade < 75
        letter = "C";
    elseif grade >= 60 && grade < 70
        letter = "D";
    elseif grade < 60
        letter = "F";
    end
end

function bool = studentCheck(student)
    % This function checks that all required fields (grades) are present 
    % for a given student and that they are all numerical.
    % The output is a logical true if the grade can be calculated or a
    % logical false if there is missing information or non-numerical
    % values.
    fieldBool = [
        isfield(student,'exams')
        isfield(student,'labs')
        isfield(student,'quizzes')
        isfield(student,'projects')];
    
    if all(fieldBool)
        numBool = [
            isnumeric(student.exams)
            isnumeric(student.labs)
            isnumeric(student.quizzes)
            isnumeric(student.projects)];
    else
        bool = false;
        return
    end
    bool = all(numBool);
end