function piCalcs1(tol)
    if nargin ~= 1
        tol = 1e-4;
    end
    Wells(tol);
    GregoryLeibniz(tol);
    Bellard(tol);
    BorweinBailey(tol)
    Euler(tol)
end

function Wells(tol)
    err = inf;
    k = 0;
    mypi = 2;
    while err > tol
        k = k+1;
        num = (2*k)^2;
        den = (2*k-1)*(2*k+1);
        mypi = mypi*(num/den);
        err = abs(pi - mypi);
    end
    printFunc('Wells pi series', tol, k)
end

function GregoryLeibniz(tol)
    err = inf;
    k = 0;
    mypi = 0;
    while err > tol
        k = k + 1;
        num = (-1)^(k+1);
        den = 2*k-1;
        mypi = mypi + num/den;
        err = abs(pi - 4*mypi);
    end
    printFunc('Gregory-Leibniz pi series', tol, k)
end

function Bellard(tol)
    err = inf;
    k = 0;
    mypi = 0;
    while err > tol
        num = (-1)^(k);
        den = 2^(10*k);
        phi = num/den;
        terms = [-(2^5)/(4*k+1)
                -(1)/(4*k+3)
                (2^8)/(10*k+1)
                -(2^6)/(10*k+3)
                -(2^2)/(10*k+5)
                -(2^2)/(10*k+7)
                (1)/(10*k+9)];
        mypi = mypi + phi*sum(terms);
        err = abs(pi - (2^-6)*mypi);
        k = k + 1;
    end
    printFunc('Bellard pi series', tol, k)
end

function BorweinBailey(tol)
    err = inf;
    k = 0;
    mypi = 0;
    while err > tol
        phi = 16^-k;
        terms = [(4)/(8*k+1)
                -(2)/(8*k+4)
                -(1)/(8*k+5)
                -(1)/(8*k+6)];
        mypi = mypi + phi*sum(terms);
        err = abs(pi - mypi);
        k = k + 1;
    end
    printFunc('Borwein-Bailey pi series', tol, k)
end

function Euler(tol)
    err = inf;
    k = 1;
    s = 0;
    while err > tol
        s = s + 6/k^2;
        err = abs(pi - sqrt(s));
        k = k + 1;
    end
    printFunc('Euler pi series', tol, k-1)
end

function printFunc(name, tol, n)
    fprintf('\nThe %s converged to pi within %0.1e in %d iterations\n',name,tol,n)
end
