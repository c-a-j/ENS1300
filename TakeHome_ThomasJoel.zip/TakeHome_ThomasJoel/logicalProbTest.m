% import the data
% call your logicalProb function
