function movingAverages(dates, prices)
    if nargin ~=2
        filePath = fullfile('data','BTC.mat');
        load(filePath,'dates','prices');
        dates = dates(1:394);
        prices = prices(1:394);
        clear filePath;
    end
    
end