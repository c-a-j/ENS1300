function doubleFunc(var,~)
    if nargin == 1
        if isa(var,'double')
            [r,c] = size(var);
            fprintf('Input is a double with dimensions %dx%d\n', r, c);
        else
            fprintf('Error: Input is not a double\n')
            return
        end
    else
        fprintf('Error: Invalid number of inputs\n')
        return
    end       
end