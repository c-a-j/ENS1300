%% doubleFunc
doubleFunc('foo')
doubleFunc(1)
doubleFunc([1,2,3])
doubleFunc('foo', [1,2,3])

%% calcGrade3
fileName = 'grades.mat';
filePath = 'data';
fullPath = fullfile(filePath,fileName);
load(fullPath)
student = 'student314';
students.(student) = calcGrade3(students.(student));
grade = students.(student).avgGrade;
letter = students.(student).letterGrade;
fprintf('%s''s average grade is %0.2f (%s)\n', student, grade, letter)

%% cart2sphere_flex
fileName = 'cartesianCoordinates.csv';
filePath = 'data';
fullPath = fullfile(filePath,fileName);
mat1 = [1,2,3];
mat2 = [1,2,3;4,5,6;7,8,9];

% NOTE: this only tests the cases where inputs are formatted properly
% You would also want/need to test the invalid input cases as well.
sphereCoords = cart2sphere_flex;
sphereCoords = cart2sphere_flex(mat1);
sphereCoords = cart2sphere_flex(mat2);
sphereCoords = cart2sphere_flex(fullPath); % I added this usage, this was not a part of the lab
sphereCoords = cart2sphere_flex(fullPath,'outputFile.csv');

%% logicalPract1
fileName = 'LP1data.csv';
filePath = 'data';
fullPath = fullfile(filePath,fileName);
logicalPract1(fullPath);

%% logicalPract2
fileName = 'LP2data.csv';
filePath = 'data';
fullPath = fullfile(filePath,fileName);
results = logicalPract2(fullPath);







