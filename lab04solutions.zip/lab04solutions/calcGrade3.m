function student = calcGrade3(student)
    avgGrade = mean(student.exams)*0.4 + mean(student.labs)*0.4 ...
        + mean(student.quizzes)*0.1 + mean(student.projects)*0.1;
    
    if avgGrade >= 90
        letterGrade = "A";
    elseif avgGrade >= 85 && avgGrade < 90
        letterGrade = "B+";
    elseif avgGrade >= 80 && avgGrade < 85
        letterGrade = "B";
    elseif avgGrade >= 75 && avgGrade < 80
        letterGrade = "C+";
    elseif avgGrade >= 70 && avgGrade < 75
        letterGrade = "C";
    elseif avgGrade >= 60 && avgGrade < 70
        letterGrade = "D";
    elseif avgGrade < 60
        letterGrade = "F";
    end
    
    student.avgGrade = avgGrade;
    student.letterGrade = letterGrade;
end