function o = logicalPract2(fp)
    %%% Part a
    data = csvread(fp);
    time = data(:,1);
    s1 = data(:,2);
    s2 = data(:,3);
    
    %%% Part b
    numNaN = sum(isnan(s1));
    fprintf('The number of NaNs is %d\n',numNaN)
    
    %%% Part c
    s1 = s1(~isnan(s1));
    ts1 = time(~isnan(s1));
    
    %%% Part d
    sensor1.max = [ts1(s1==max(s1)), max(s1)];
    sensor2.max = [time(s2==max(s2)), max(s2)];
    sensor1.min = [ts1(s1==min(s1)), min(s1)];
    sensor2.min = [time(s2==min(s2)), min(s2)];
    sensor1.above1000 = sum(s1>1000);
    sensor2.above1000 = sum(s2>1000);
    sensor1.below1000 = sum(s1<1000);
    sensor2.below1000 = sum(s2<1000);
    sensor1.Neg100toPos100 = sum(s1<100 & s1>-100);
    sensor2.Neg100toPos100 = sum(s2<100 & s2>-100);
    
    o.sensor1 = sensor1;
    o.sensor2 = sensor2;
    
    %%% Part e
    plot(ts1,s1,'b.'); hold on
    plot(time,s2,'r.')
    xlabel('Independent Values')
    ylabel('Dependent Values')
    title('Logical Practice 2')
    legend('Sensor 1', 'Sensor 2')
end







