function logicalPract1(fp)
    %%% Part a
    data = csvread(fp);
    
    %%% Part b
    numNaN = sum(sum(isnan(data)));
    fprintf('The number of NaNs is %d\n',numNaN)
    
    %%% Part c
    data = data(~isnan(data)); 
    % data is now a vector because not every column in the original matrix
    % contained the same number of NaN elements. Each non-NaN value in
    % every column is stacked sequentially into a single column.
    
    %%% Part d
    dataDescend = sort(data,'descend');
    fprintf('Mean of the largest 1000 elements = %0.2f\n', mean(dataDescend(1:1000)))
    
    dataAscend = sort(data);
    fprintf('Mean of the smallest 1000 elements = %0.2f\n', mean(dataAscend(1:1000)))
    
    fprintf('Sum of the 150th, 200th, 1,000th, 20,000th, and 100,000th elements = %0.2f\n',...
        sum(data([150,200,1000,20000,100000])))
    
    fprintf('Standard deviation of all the values contained in even elements = %0.2f\n',...
        std(data(2:2:end)))
    
    fprintf('Square root of the sum of the squares of all values contained in odd elements = %0.2f\n',...
        norm(data(1:2:end)))
    
    fprintf('Number of values that are greater than or equal to the mean = %d\n',...
        sum(data>=mean(data)))
    
    fprintf('Number of values that are less than the median = %d\n',...
        sum(data<median(data)))
end







