function sphereCoords = cart2sphere_flex(arg1, arg2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Purpose: sphereCoords() converts cartesian coordinates to spherical
%%% Inputs: user can supply either zero, one, or two arguments
%%% Output: shpereCoords will an array of spherical coordinates
%%% Usage 1: sphereCoords = cart2sphere();
%%% Usage 2: sphereCoords = cart2sphere(input); 
    % input can be an n by 3 double 
    % input can be a string/char containing path and name of input csv file
%%% Usage 3: sphereCoords = cart2sphere(iFile, oFile); 
    % iFile is string/char containing path and name of input csv file
    % oFile is string/char containing path and name of output csv file
%%% Notes: the input csv file must contain only numbers
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if nargin == 0
        cartCoords = getInput();
        sphereCoords = convertCoords(cartCoords);
        printOutput(sphereCoords);
    elseif nargin == 1 && isa(arg1, 'double')
        matrixCheck(arg1);
        if length(arg1(:,1)) == 1
            sphereCoords = convertCoords(arg1);
            printOutput(sphereCoords);
        else
            sphereCoords = convertCoords(arg1);
            printOutput(sphereCoords);
        end
    elseif nargin == 1
        stringCheck(arg1);
        cartCoords = readInput(arg1);
        sphereCoords = convertCoords(cartCoords);
    elseif nargin == 2 
        stringCheck(arg1,arg2);
        cartCoords = readInput(arg1);
        sphereCoords = convertCoords(cartCoords);
        printOutput(sphereCoords);
        writeOutput(arg1, arg2);
    end
end

function cartCoords = readInput(ifile)
% read the input file fom csv
    cartCoords = csvread(ifile);
end

function cartCoords = getInput()
% get single input coordinate fom user via command window
    cartCoords = input('Enter the cartesian coordinates of a point in vector format [x y z]: ');
end

function sphereCoords = convertCoords(cartCoords)
% convert the coordinates
    x = cartCoords(:,1); 
    y = cartCoords(:,2);
    z = cartCoords(:,3);
    r = (x.^2 + y.^2 + z.^2).^(1/2);
    theta = acosd(z./r);
    phi = atand(y./x);
    sphereCoords = [r, theta, phi];
end

function printOutput(sphereCoords)
% print results to command window
    r = sphereCoords(:,1); 
    theta = sphereCoords(:,2);
    phi = sphereCoords(:,3);
    if length(r) == 1
        fprintf('\nThe radius is %0.2f\n', r)
        fprintf('The inclanation angle is %0.2f\n', theta)
        fprintf('The azimuth angle is %0.2f\n\n', phi)
    else
        fprintf('\nThe average radius is %0.2f\n', mean(r))
        fprintf('The average inclanation angle is %0.2f\n', mean(theta))
        fprintf('The average azimuth angle is %0.2f\n\n', mean(phi))
    end
end

function writeOutput(sphereCoords, ofile)
% write results to a csv file
    csvwrite(ofile, sphereCoords)
    fprintf('\nResult file, %s, written successfully.\n', ofile)
end

function matrixCheck(arg1)
% check input matrix dimentions
    if isa(arg1, 'double')
        if length(arg1(1,:)) == 3
            return
        end
    end
    error('Invalid input matrix')
end

function stringCheck(arg1, arg2)
% ensure both inputs are string or char
    if nargin == 1
        cond1 = (isa(arg1,'char') || isa(arg1,'string'));
        cond2 = true;
    elseif nargin == 2
        cond1 = (isa(arg1,'char') || isa(arg1,'string'));
        cond2 = (isa(arg2,'char') || isa(arg2,'string'));
    end
    
    if cond1 && cond2
        return
    else
        error('Invalid inputs')
    end
end