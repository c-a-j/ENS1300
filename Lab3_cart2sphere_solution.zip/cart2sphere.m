function sphereCoords = cart2sphere(iFile, oFile)
%%% Purpose: sphereCoords() converts cartesian coordinates to spherical
%%% Inputs:
    % iFile is string/char containing path and name of input csv file
    % oFile is string/char containing path and name of output csv file
%%% Output: 
    % shpereCoords is an array of spherical coordinates
%%% Usage: sphereCoords = cart2sphere(iFile, oFile); 
%%% Notes: the input csv file must contain only numbers
    cartCoords = readInput(iFile);
    sphereCoords = convertCoords(cartCoords);
    printOutput(sphereCoords);
    writeOutput(sphereCoords, oFile);
end

function cartCoords = readInput(ifile)
% read the input file fom csv
    cartCoords = csvread(ifile);
end

function sphereCoords = convertCoords(cartCoords)
% convert the coordinates
    x = cartCoords(:,1); 
    y = cartCoords(:,2);
    z = cartCoords(:,3);
    r = (x.^2 + y.^2 + z.^2).^(1/2);
    theta = acosd(z./r);
    phi = atand(y./x);
    sphereCoords = [r, theta, phi];
end

function printOutput(sphereCoords)
% print results summary to command window
    r = sphereCoords(:,1); 
    theta = sphereCoords(:,2);
    phi = sphereCoords(:,3);
    if length(r) == 1
        fprintf('\nThe radius is %0.2f\n', r)
        fprintf('The inclanation angle is %0.2f\n', theta)
        fprintf('The azimuth angle is %0.2f\n\n', phi)
    else
        fprintf('\nThe average radius is %0.2f\n', mean(r))
        fprintf('The average inclanation angle is %0.2f\n', mean(theta))
        fprintf('The average azimuth angle is %0.2f\n\n', mean(phi))
    end
end

function writeOutput(sphereCoords, ofile)
% write results to a csv file
    csvwrite(ofile, sphereCoords)
    fprintf('\nResult file, %s, written successfully.\n', ofile)
end