function convertTest
   %%% CHANGE THESE VARIABLES
   func = @timeConverter; % change timeConverter to your function name
   units = ["second", "minute", "hour", "day", "week", "year"];
   x = 1; % this is the number being converted
   
   %%% DONT CHANGE THIS LOOP
   % this loops through each combination of the units array
   for i = units
       for j = units
           fprintf('1 %s equals %0.3e %s\n', i, func(x, i, j), j);
       end
           fprintf('\n');
   end
end