function y = timeConverter(x, u1, u2)
    %%% second
    if u1 == "second"
        if u2 == u1
            y = x;
            return
        elseif u2 == "minute"
            y = second2minute(x);
            return
        elseif u2 == "hour"
            y = second2hour(x);
            return
        elseif u2 == "day"
            y = second2day(x);
            return
        elseif u2 == "week"
            y = second2week(x);
            return
        elseif u2 == "year"
            y = second2year(x);
            return
        else
            y = notFound(u2);
            return
        end
    end
    
    %%% minute
    if u1 == "minute"
        if u2 == u1
            y = x;
            return
        elseif u2 == "second"
            y = minute2second(x);
            return
        elseif u2 == "hour"
            y = minute2hour(x);
            return
        elseif u2 == "day"
            y = minute2day(x);
            return
        elseif u2 == "week"
            y = minute2week(x);
            return
        elseif u2 == "year"
            y = minute2year(x);
            return
        else
            y = notFound(u2);
            return
        end
    end
   
    %%% hour
    if u1 == "hour"
        if u2 == u1
            y = x;
            return
        elseif u2 == "second"
            y = hour2second(x);
            return
        elseif u2 == "minute"
            y = hour2minute(x);
            return
        elseif u2 == "day"
            y = hour2day(x);
            return
        elseif u2 == "week"
            y = hour2week(x);
            return
        elseif u2 == "year"
            y = hour2year(x);
            return
        else
            y = notFound(u2);
            return
        end
    end

    %%% day
    if u1 == "day"
        if u2 == u1
            y = x;
            return
        elseif u2 == "second"
            y = day2second(x);
            return
        elseif u2 == "minute"
            y = day2minute(x);
            return
        elseif u2 == "hour"
            y = day2hour(x);
            return
        elseif u2 == "week"
            y = day2week(x);
            return
        elseif u2 == "year"
            y = day2year(x);
            return
        else
            y = notFound(u2);
            return
        end
    end

    %%% week
    if u1 == "week"
        if u2 == u1
            y = x;
            return
        elseif u2 == "second"
            y = week2second(x);
            return
        elseif u2 == "minute"
            y = week2minute(x);
            return
        elseif u2 == "hour"
            y = week2hour(x);
            return
        elseif u2 == "day"
            y = week2day(x);
            return
        elseif u2 == "year"
            y = week2year(x);
            return
        else
            y = notFound(u2);
            return
        end
    end

    %%% year
    if u1 == "year"
        if u2 == u1
            y = x;
            return
        elseif u2 == "second"
            y = year2second(x);
            return
        elseif u2 == "minute"
            y = year2minute(x);
            return
        elseif u2 == "hour"
            y = year2hour(x);
            return
        elseif u2 == "day"
            y = year2day(x);
            return
        elseif u2 == "week"
            y = year2week(x);
            return
        else
            y = notFound(u2);
            return
        end
    end
    y = notFound(u1);
end

%%% second
function y = second2minute(x)
    y = x*(1/60);
end
function y = second2hour(x)
    y = x*(1/60^2);
end
function y = second2day(x)
    y = x*(1/60^2)*(1/24);
end
function y = second2week(x)
    y = x*(1/60^2)*(1/24)*(1/7);
end
function y = second2year(x)
    y = x*(1/60^2)*(1/24)*(1/365);
end

%%% minute
function y = minute2second(x)
    y = x*(60);
end
function y = minute2hour(x)
    y = x*(1/60);
end
function y = minute2day(x)
    y = x*(1/60)*(1/24);
end
function y = minute2week(x)
    y = x*(1/60)*(1/24)*(1/7);
end
function y = minute2year(x)
    y = x*(1/60)*(1/24)*(1/365);
end

%%% hour
function y = hour2second(x)
    y = x*(60^2);
end
function y = hour2minute(x)
    y = x*(60);
end
function y = hour2day(x)
    y = x*(1/24);
end
function y = hour2week(x)
    y = x*(1/24)*(1/7);
end
function y = hour2year(x)
    y = x*(1/24)*(1/365);
end

%%% day
function y = day2second(x)
    y = x*(24)*(60^2);
end
function y = day2minute(x)
    y = x*(24)*(60);
end
function y = day2hour(x)
    y = x*(24);
end
function y = day2week(x)
    y = x*(1/7);
end
function y = day2year(x)
    y = x*(1/365);
end

%%% week
function y = week2second(x)
    y = x*(7)*(24)*(60^2);
end
function y = week2minute(x)
    y = x*(7)*(24)*(60);
end
function y = week2hour(x)
    y = x*(7)*(24);
end
function y = week2day(x)
    y = x*(7);
end
function y = week2year(x)
    y = x*(1/52.1429);
end

%%% year
function y = year2second(x)
    y = x*(365)*(24)*(60^2);
end
function y = year2minute(x)
    y = x*(365)*(24)*(60);
end
function y = year2hour(x)
    y = x*(365)*(24);
end
function y = year2day(x)
    y = x*(365);
end
function y = year2week(x)
    y = x*(52.1429);
end
