function y = notFound(u)
    y = [];
    fprintf('Error: the unit, %s, is unrecognized\n', u);
end