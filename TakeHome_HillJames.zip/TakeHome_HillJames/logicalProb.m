function logicalProb

end
